package com.hxb.TEXT;

import com.hxb.jdbc.Jdbc;
import com.sun.org.apache.xerces.internal.dom.PSVIAttrNSImpl;

import java.sql.SQLException;

/**
 * -*- coding = utf-8 -*-
 * 2020/6/16 21:09
 * 和学博
 * IntelliJ IDEA
 */
public class TEXT1 {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Jdbc.getcollection();
    }
}
